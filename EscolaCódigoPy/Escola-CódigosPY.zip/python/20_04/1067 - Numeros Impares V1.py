x = int(input())
impar = 1

while impar <= x:
    if impar % 2 == 1:
        print(impar)
    impar += 1
    
