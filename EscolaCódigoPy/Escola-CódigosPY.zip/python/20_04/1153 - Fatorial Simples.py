n = int(input())
fat = 1
i = 1

while i <= n:
    fat = fat * i
    i += 1
print(fat)
