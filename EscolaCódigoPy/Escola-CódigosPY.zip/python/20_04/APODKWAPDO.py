n = int(input())


while 
x = chr((65 + n))
print(x)


    
    
