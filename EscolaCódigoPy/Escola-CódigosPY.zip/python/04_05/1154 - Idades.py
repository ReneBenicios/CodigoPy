n = int(input())

if n > 0:
    
        
        
        
