N = int(input())
qtd = 0
valor = 2
while qtd < N:
    qtd += 2
    multi = qtd * qtd
    print(f"{qtd}^{valor} = {multi}")
