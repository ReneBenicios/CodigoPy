a = int(input())
qtd = 0
x = 0

while qtd < a :
    print(x)
    x += 2
    qtd += 1
print("Fim")
