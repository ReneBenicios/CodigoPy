n = int(input())
qtd = 0
x = 10

while qtd < n:
    print(x)
    x += 1
    qtd += 1
print("fim")
