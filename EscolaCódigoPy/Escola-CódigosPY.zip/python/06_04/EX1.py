qtd = 0
x = 10

while qtd < 5 :
    print(x)
    x += 1
    qtd += 1

print("fim")
