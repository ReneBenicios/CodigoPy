qtd = 0

x = 1

while qtd < 50:
    print(x)
    x += 1
    qtd += 1
    
print("fim")
