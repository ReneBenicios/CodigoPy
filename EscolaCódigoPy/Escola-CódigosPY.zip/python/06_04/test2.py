x = 1

print(x)
x += 1

print(x)
x += 1

print(x)
x += 1

print(x)
x += 1

print(x)
x += 1


