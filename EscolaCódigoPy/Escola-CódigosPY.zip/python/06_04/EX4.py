a = int(input())
b = int(input())

while a <= b :
    print(a)
    a += 1
    
print("fim")
