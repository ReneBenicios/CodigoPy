n = int(input())
qtd = 0
x = int(input())

while qtd < n:
    print(x)
    x += 1
    qtd += 1
print("fim")
