## Exemplos de Sequências


idade = [35, 29, 72, 80, 15]

I = range(10,16,1)
print(I)

#range(10,16,1)
#range(inicio,fim,passo)

## Exemplo de Listas
## Exemplo de Listas

## exemplo de forma decrecesnte
Test = range(20, 9, -1)
##list(Test)
print(Test)

## Exemplo de forma Crescente

Test2 = range(5, 20, 1)
##list(Test2)
print(Test2)
